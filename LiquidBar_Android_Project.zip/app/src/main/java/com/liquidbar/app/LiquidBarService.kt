package com.liquidbar.app

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.widget.TextView
import android.provider.Settings

class LiquidBarService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var expanded = false
    private var downX = 0f
    private var downY = 0f
    private var moved = false

    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        val channel = "liquidbar"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channel, "LiquidBar overlay", NotificationManager.IMPORTANCE_LOW))
        }
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channel).setContentTitle("LiquidBar active")
                .setContentText("Your glass navigation companion is running")
                .setSmallIcon(android.R.drawable.ic_menu_view).build()
        else Notification.Builder(this).setContentTitle("LiquidBar active")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        startForeground(7, notification)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPill()
    }

    private fun glass(bg: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply { setColor(bg); cornerRadius = radius; setStroke(1, 0x66FFFFFF) }

    private fun showPill() {
        val label = TextView(this).apply {
            text = "  ◉   LiquidBar   "
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = glass(0xE8172030.toInt(), 80f)
            elevation = 18f
            setPadding(22, 13, 22, 13)
        }
        @Suppress("DEPRECATION")
        val overlayType = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 12
        }
        label.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; moved=false; true }
                MotionEvent.ACTION_MOVE -> {
                    if (kotlin.math.abs(e.rawX-downX) > 24 || kotlin.math.abs(e.rawY-downY) > 24) moved=true
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val dx=e.rawX-downX
                    if (moved && kotlin.math.abs(dx)>45) showShelf()
                    else if (!moved) toggleIsland()
                    true
                }
                else -> true
            }
        }
        bubble = label
        wm.addView(label, p)
    }

    private fun toggleIsland() {
        expanded = !expanded
        (bubble as? TextView)?.apply {
            text = if (expanded) "  ◉   Music  •  Shortcuts  •  Timer  ✕  " else "  ◉   LiquidBar   "
            setPadding(if (expanded) 26 else 22, if (expanded) 20 else 13,
                if (expanded) 26 else 22, if (expanded) 20 else 13)
        }
    }

    private fun showShelf() {
        expanded = true
        (bubble as? TextView)?.apply {
            text = "  Apps     Tools     Screenshot     Settings     ✕  "
            setPadding(26, 20, 26, 20)
        }
    }

    override fun onDestroy() {
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }
}
