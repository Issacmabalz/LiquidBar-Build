package com.liquidbar.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val bg = 0xFF090D16.toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(24, 36, 24, 24)
            setBackgroundColor(bg)
        }
        fun text(s: String, size: Float, color: Int = Color.WHITE) =
            TextView(this).apply { text=s; textSize=size; setTextColor(color); setPadding(0,10,0,10) }
        root.addView(text("LiquidBar", 32f))
        root.addView(text("A glassy, gesture-driven navigation companion", 14f, 0xFFB8C5D8.toInt()))
        root.addView(text("QUICK SETUP", 12f, 0xFF71D9FF.toInt()))
        root.addView(text("1. Allow display over other apps.\n2. Start LiquidBar.\n3. Tap the pill to open the island; swipe sideways for Edge Shelf; long-press for your assistant.", 15f))
        val overlay = Button(this).apply {
            text = if (Settings.canDrawOverlays(this@MainActivity)) "Start LiquidBar" else "Grant overlay permission"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    startForegroundService(Intent(this@MainActivity, LiquidBarService::class.java))
                    text = "LiquidBar is running"
                }
            }
        }
        root.addView(overlay)
        root.addView(text("CUSTOMIZATION", 12f, 0xFF71D9FF.toInt()))
        root.addView(text("Prototype defaults: midnight glass • cyan accent • compact pill • spring-like transitions. Full per-app controls, live media artwork and true system navigation integration are planned for the next build.", 14f, 0xFFB8C5D8.toInt()))
        setContentView(root)
    }
}
