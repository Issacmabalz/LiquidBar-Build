# LiquidBar — Android prototype

This is a starter Android Studio project for a floating, liquid-glass navigation companion.

## Build
1. Open this folder in Android Studio (recent stable version).
2. Allow Gradle to sync and install the Android SDK Platform 35 if prompted.
3. Select **Build → Build APK(s)**.
4. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Current prototype
- Floating glass pill overlay.
- Tap expands/collapses a Dynamic-Island-inspired panel.
- Side swipe changes the pill into an Edge-Shelf-style strip.
- Foreground notification keeps the overlay service visible to Android.

## Important limitations
- This is a prototype, not a finished replacement for Android's system navigation bar.
- Android does not let an ordinary app silently replace the system navigation bar. A production implementation needs carefully designed gesture/accessibility integration and user-granted permissions.
- Long-press assistant launch, true Back/Home/Recents actions, live media-session artwork and playback controls, and extensive settings are not implemented yet.
- 120 FPS cannot be guaranteed. The POCO C55 display is 60 Hz, so it cannot show 120 distinct frames per second. Animations should adapt to the display refresh rate.
- No app can promise zero performance impact; this prototype keeps the overlay lightweight, but an always-on overlay still uses some memory and rendering time.

## Package
`com.liquidbar.app`
